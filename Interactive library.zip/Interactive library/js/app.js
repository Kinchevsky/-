// ===== ОБРАБОТЧИКИ ДЕЙСТВИЙ =====
const ActionHandlers = {
    addRandomBook() {
        const MAX_BOOKS = 50;
        
        if (Library.books.length >= MAX_BOOKS) {
            NotificationSystem.show('Превышен лимит добавления книг (максимум 50)', 'error');
            const btn = document.querySelector('#add-random');
            if (btn) btn.disabled = true;
            return;
        }
        
        const newBook = generateRandomBook();
        Library.add(newBook);
        BookListRenderer.render();
        NotificationSystem.show(`Добавлена книга: "${newBook.title}"`, 'success');
        
        // Анимация скролла к новой книге
        setTimeout(() => {
            const bookElement = document.querySelector(`[data-book-id="${newBook.id}"]`);
            if (bookElement) {
                bookElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                bookElement.style.transform = 'scale(1.02)';
                setTimeout(() => {
                    if (bookElement) bookElement.style.transform = '';
                }, 500);
            }
        }, 100);
    },
    
    filterAll() {
        Library.activeFilter = 'all';
        BookListRenderer.render();
        
        // Визуальная индикация активной кнопки
        const allBtn = document.querySelector('#filter-all');
        const readBtn = document.querySelector('#filter-read');
        if (allBtn && readBtn) {
            allBtn.style.transform = 'scale(1.05)';
            readBtn.style.transform = 'scale(1)';
        }
    },
    
    filterRead() {
        Library.activeFilter = 'read';
        BookListRenderer.render();
        
        const allBtn = document.querySelector('#filter-all');
        const readBtn = document.querySelector('#filter-read');
        if (allBtn && readBtn) {
            allBtn.style.transform = 'scale(1)';
            readBtn.style.transform = 'scale(1.05)';
        }
    },
    
    clearAll() {
        if (Library.books.length === 0) {
            NotificationSystem.show('Библиотека уже пуста', 'info');
            return;
        }
        
        const confirmed = confirm(`Удалить все книги (${Library.books.length} шт.)?`);
        if (confirmed) {
            const count = Library.books.length;
            Library.clear();
            BookListRenderer.render();
            NotificationSystem.show(`Удалено ${count} книг из библиотеки`, 'warning');
        }
    }
};

// ===== ИНИЦИАЛИЗАЦИЯ ИНТЕРФЕЙСА =====
function createUIStructure() {
    // Создание списка книг
    const bookListDiv = document.querySelector('#book-list');
    if (bookListDiv) {
        bookListDiv.innerHTML = '<h2>Список книг</h2><ol id="books"></ol>';
    }
    
    // Создание формы добавления
    const bookFormDiv = document.querySelector('#book-form');
    if (bookFormDiv) {
        bookFormDiv.innerHTML = `
            <h2>➕ Добавить книгу</h2>
            <button id="add-random" class="btn-primary" title="Добавить одну книгу со случайными данными">Добавить случайную книгу</button>
        `;
    }
    
    // Создание панели управления
    const controlsDiv = document.querySelector('#controls');
    if (controlsDiv) {
        controlsDiv.innerHTML = `
            <h2>🎮 Управление библиотекой</h2>
            <div class="controls-group">
                <button id="filter-all" class="btn-info" title="Показать все книги">Показать все книги</button>
                <button id="filter-read" class="btn-info" title="Показать только прочитанные книги">Показать прочитанные</button>
                <button id="clear-all" class="btn-danger" title="Очистить всю библиотеку">🗑️ Очистить список</button>
            </div>
        `;
    }
    
    // Создание статистики
    const statisticsDiv = document.querySelector('#statistics');
    if (statisticsDiv) {
        statisticsDiv.innerHTML = '<h2>Статистика</h2><div id="stats-content"></div>';
    }
    
    // Очистка контейнера уведомлений
    const messageContainer =


document.querySelector('#message-container');
    if (messageContainer) {
        messageContainer.innerHTML = '';
    }
}

// Подключение обработчиков событий
function attachEventHandlers() {
    const addBtn = document.querySelector('#add-random');
    if (addBtn) {
        addBtn.addEventListener('click', ActionHandlers.addRandomBook);
    }
    
    const filterAllBtn = document.querySelector('#filter-all');
    if (filterAllBtn) {
        filterAllBtn.addEventListener('click', ActionHandlers.filterAll);
    }
    
    const filterReadBtn = document.querySelector('#filter-read');
    if (filterReadBtn) {
        filterReadBtn.addEventListener('click', ActionHandlers.filterRead);
    }
    
    const clearAllBtn = document.querySelector('#clear-all');
    if (clearAllBtn) {
        clearAllBtn.addEventListener('click', ActionHandlers.clearAll);
    }
}

// Инициализация начальных данных
function initDefaultData() {
    const defaultBooks = [
        { id: 1, title: "Мастер и Маргарита", author: "Михаил Булгаков", year: "1967", read: true },
        { id: 2, title: "1984", author: "Джордж Оруэлл", year: "1949", read: false },
        { id: 3, title: "Война и мир", author: "Лев Толстой", year: "1869", read: true }
    ];
    
    Library.books = [...defaultBooks];
    Library.nextId = 4;
}

// Главная функция инициализации
function init() {
    createUIStructure();
    attachEventHandlers();
    initDefaultData();
    BookListRenderer.render();
    NotificationSystem.show('Добро пожаловать в цифровую библиотеку! ', 'info');
}

// Запуск приложения
init();