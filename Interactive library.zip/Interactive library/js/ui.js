// ===== СИСТЕМА УВЕДОМЛЕНИЙ =====
const NotificationSystem = {
    show(message, type = 'info') {
        const container = document.querySelector('#message-container');
        if (!container) return;
        
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        
        const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
        
        notification.innerHTML = `
            <span>${icons[type] || 'ℹ️'}</span>
            <span style="flex: 1;">${message}</span>
            <span class="notification-close">✕</span>
        `;
        
        const closeBtn = notification.querySelector('.notification-close');
        closeBtn.addEventListener('click', () => notification.remove());
        
        container.appendChild(notification);
        
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 3000);
    }
};

// ===== РЕНДЕРИНГ СПИСКА КНИГ =====
const BookListRenderer = {
    render() {
        const container = document.querySelector('#books');
        if (!container) return;
        
        const books = Library.getFilteredBooks();
        
        if (books.length === 0) {
            container.innerHTML = '<div class="empty-message">Библиотека пуста. Добавьте первую книгу.</div>';
            this.updateFooterCounter();
            this.updateStatistics();
            return;
        }
        
        container.innerHTML = '';
        
        for (const book of books) {
            const li = document.createElement('li');
            li.className = `book-item ${book.read ? 'book-read' : 'book-unread'}`;
            li.dataset.bookId = book.id;
            
            li.innerHTML = `
                <div class="book-info">
                    <span class="book-title">${escapeHtml(book.title)}</span>
                    <span> - ${escapeHtml(book.author)}</span>
                    <span> (${book.year})</span>
                    ${book.read ? '<span class="read-badge"> ПРОЧИТАНО </span>' : ''}
                </div>
                <div class="book-actions">
                    <button class="btn-toggle btn-${book.read ? 'warning' : 'success'}">${book.read ? ' Не прочитано' : ' Прочитано'}</button>
                    <button class="btn-delete btn-danger"> Удалить </button>
                </div>
            `;
            
            const toggleBtn = li.querySelector('.btn-toggle');
            const deleteBtn = li.querySelector('.btn-delete');
            
            toggleBtn.addEventListener('click', () => this.handleToggle(book.id));
            deleteBtn.addEventListener('click', () => this.handleDelete(book.id));
            
            container.appendChild(li);
        }
        
        this.updateStatistics();
        this.updateFooterCounter();
    },
    
    handleToggle(id) {
        const book = Library.books.find(b => b.id === id);
        if (book) {
            Library.toggleRead(id);
            this.render();
            NotificationSystem.show(`Статус книги "${book.title}" изменен`, 'info');
        }
    },
    
    handleDelete(id) {
        const book = Library.books.find(b => b.id === id);
        if (book) {
            Library.remove(id);
            this.render();
            NotificationSystem.show(`Книга "${book.title}" удалена`, 'info');
        }
    },
    
    updateStatistics() {
        const statsContainer = document.querySelector('#stats-content');
        if (!statsContainer) return;
        
        const stats = Library.getStats();
        statsContainer.innerHTML = `
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number">${stats.total}</div>
                    <div class="stat-label">Всего книг</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">${stats.read}</div>
                    <div class="stat-label">Прочитано</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">${stats.unread}</div>
                    <div class="stat-label">Не прочитано</div>
                </div>
            </div>
        `;
    },
    
    updateFooterCounter() {
        const counter = document.querySelector('#total-counter');
        if (counter) {
            counter.textContent = Library.books.length;
        }
    }
};