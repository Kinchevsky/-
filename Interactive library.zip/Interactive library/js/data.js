// ===== БАЗА ДАННЫХ КНИГ =====
const BOOKS_DATABASE = {
    titles: [
        "Мастер и Маргарита", "Преступление и наказание", "Война и мир", "Анна Каренина",
        "Мёртвые души", "Евгений Онегин", "Отцы и дети", "Герой нашего времени",
        "Идиот", "Братья Карамазовы", "Тихий Дон", "Доктор Живаго",
        "1984", "Убить пересмешника", "Великий Гэтсби", "Над пропастью во ржи",
        "Повелитель мух", "Фауст", "Дон Кихот", "Гамлет",
        "Моби Дик", "Гордость и предубеждение", "Ярмарка тщеславия", "Маленькие женщины"
    ],
    authors: [
        "Михаил Булгаков", "Фёдор Достоевский", "Лев Толстой", "Александр Пушкин",
        "Николай Гоголь", "Иван Тургенев", "Михаил Лермонтов", "Антон Чехов",
        "Иван Бунин", "Александр Солженицын", "Максим Горький", "Владимир Набоков",
        "Джордж Оруэлл", "Харпер Ли", "Фрэнсис Скотт Фицджеральд", "Джером Сэлинджер",
        "Уильям Голдинг", "Иоганн Гёте", "Мигель де Сервантес", "Уильям Шекспир",
        "Герман Мелвилл", "Джейн Остин", "Уильям Теккерей", "Луиза Мэй Олкотт"
    ],
    years: Array.from({length: 200}, (_, i) => (1800 + i).toString())
};

// ===== СТИЛИ ДЛЯ УВЕДОМЛЕНИЙ =====
const NOTIFICATION_STYLES = {
    success: { backgroundColor: '#d4edda', color: '#155724', borderColor: '#c3e6cb' },
    error: { backgroundColor: '#f8d7da', color: '#721c24', borderColor: '#f5c6cb' },
    info: { backgroundColor: '#d1ecf1', color: '#0c5460', borderColor: '#bee5eb' },
    warning: { backgroundColor: '#fff3cd', color: '#856404', borderColor: '#ffeeba' }
};

// ===== ОБЪЕКТ БИБЛИОТЕКИ =====
const Library = {
    books: [],
    nextId: 1,
    activeFilter: 'all',

    add(book) {
        this.books.push(book);
        this.nextId = Math.max(this.nextId, book.id + 1);
    },

    remove(id) {
        const index = this.books.findIndex(book => book.id === id);
        if (index !== -1) {
            this.books.splice(index, 1);
            return true;
        }
        return false;
    },

    toggleRead(id) {
        const book = this.books.find(book => book.id === id);
        if (book) {
            book.read = !book.read;
            return true;
        }
        return false;
    },

    clear() {
        this.books = [];
    },

    getFilteredBooks() {
        if (this.activeFilter === 'read') {
            return this.books.filter(book => book.read === true);
        }
        return [...this.books];
    },

    getStats() {
        const filtered = this.getFilteredBooks();
        const read = filtered.filter(book => book.read).length;
        return {
            total: filtered.length,
            read: read,
            unread: filtered.length - read
        };
    },

    isUnique(title, author) {
        return !this.books.some(book => book.title === title && book.author === author);
    }
};