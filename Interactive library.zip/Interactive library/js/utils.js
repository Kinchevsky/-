// ===== УТИЛИТЫ =====

// Генерация случайного числа в диапазоне
function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Генерация случайной книги
function generateRandomBook() {
    let title, author;
    let attempts = 0;
    const maxAttempts = 50;
    
    do {
        const titleIndex = Math.floor(Math.random() * BOOKS_DATABASE.titles.length);
        const authorIndex = Math.floor(Math.random() * BOOKS_DATABASE.authors.length);
        title = BOOKS_DATABASE.titles[titleIndex];
        author = BOOKS_DATABASE.authors[authorIndex];
        attempts++;
        if (attempts > maxAttempts) break;
    } while (!Library.isUnique(title, author));
    
    const yearIndex = Math.floor(Math.random() * BOOKS_DATABASE.years.length);
    const year = BOOKS_DATABASE.years[yearIndex];
    
    return {
        id: Library.nextId,
        title: title,
        author: author,
        year: year,
        read: Math.random() > 0.5
    };
}

// Экранирование HTML для защиты от XSS
function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}