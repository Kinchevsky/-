// ========== ПЕРЕМЕННЫЕ ==========
const app = document.querySelector('#app');
let currentUser = null;
let selectedCategory = "Все";
let selectedProduct = null;
let currentPage = 1;
const ITEMS_PER_PAGE = 8;

// ========== СОХРАНЕНИЕ ИЗБРАННОГО ==========
function saveFavorites() {
    localStorage.setItem("favorites", JSON.stringify(favorites));
}

function toggleFavorite(productId) {
    const index = favorites.indexOf(productId);
    if (index === -1) {
        favorites.push(productId);
    } else {
        favorites.splice(index, 1);
    }
    saveFavorites();
    
    if (currentUser) {
        showCatalogPage(currentPage);
    }
}

function isFavorite(productId) {
    return favorites.includes(productId);
}

// ========== СОРТИРОВКА ==========
function getSortedProducts(products) {
    return [...products].sort((a, b) => {
        if (a.inStock === b.inStock) return 0;
        return a.inStock ? -1 : 1;
    });
}

function getPaginatedProducts(products) {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return products.slice(start, start + ITEMS_PER_PAGE);
}

// ========== ФОРМА ВХОДА ==========
function showLoginForm() {
    app.innerHTML = `
        <div class="login-container">
            <h2>🔐 Вход в аккаунт</h2>
            <input type="text" id="login" placeholder="Логин">
            <input type="password" id="password" placeholder="Пароль">
            <div style="display: flex; gap: 10px;">
                <button id="btn" style="flex:1; padding:12px; background:#1a1a2e; color:white; border:none; border-radius:10px; cursor:pointer;">Войти</button>
                <button id="regBtn" style="flex:1; padding:12px; background:#1a1a2e; color:white; border:none; border-radius:10px; cursor:pointer;">Регистрация</button>
            </div>
            <div id="message" class="message"></div>
        </div>
    `;
    
    document.getElementById("btn").onclick = () => {
        const login = document.getElementById("login").value;
        const password = document.getElementById("password").value;
        
        if (login.length < 3 || login.length > 15) {
            showMessage("Логин должен быть 3-15 символов", true);
            return;
        }
        if (password.length < 3) {
            showMessage("Пароль должен быть минимум 3 символа", true);
            return;
        }
        
        const user = users.find(u => u.login === login && u.password === password);
        if (user) {
            currentUser = user;
            currentPage = 1;
            selectedCategory = "Все";
            showCatalogPage(1);
        } else {
            showMessage("Неверный логин или пароль", true);
        }
    };
    
    document.getElementById("regBtn").onclick = showRegisterForm;
}

function showMessage(text, isError) {
    const msgDiv = document.getElementById("message");
    if (msgDiv) {
        msgDiv.innerHTML = text;
        msgDiv.style.background = isError ? "#fee" : "#e6fffa";
        msgDiv.style.color = isError ? "#c53030" : "#276749";
    }
}

// ========== ФОРМА РЕГИСТРАЦИИ ==========
function showRegisterForm() {
    app.innerHTML = `
        <div class="login-container">
            <h3>📝 Регистрация</h3>
            <label>Логин (3-15 символов):</label>
            <input type="text" id="newLogin">
            <label>Пароль (мин. 3 символа):</label>
            <input type="password" id="newPassword">
            <label>Подтвердите пароль:</label>
            <input type="password" id="confirmPassword">
            <div style="display: flex; gap: 10px; margin-top: 20px;">
                <button id="doRegBtn" style="flex:1; padding:12px; background:#1a1a2e; color:white; border:none; border-radius:10px; cursor:pointer;">Зарегистрироваться</button>
                <button id="backBtn" style="flex:1; padding:12px; background:#718096; color:white; border:none; border-radius:10px; cursor:pointer;">Назад</button>
            </div>
            <div id="regMessage" class="message"></div>


</div>`;
    
    document.getElementById("doRegBtn").onclick = () => {
        const login = document.getElementById("newLogin").value;
        const password = document.getElementById("newPassword").value;
        const confirm = document.getElementById("confirmPassword").value;
        const msgDiv = document.getElementById("regMessage");
        
        if (login.length < 3 || login.length > 15) {
            msgDiv.innerHTML = "Логин должен быть 3-15 символов";
            msgDiv.style.background = "#fee";
            return;
        }
        if (password.length < 3) {
            msgDiv.innerHTML = "Пароль должен быть минимум 3 символа";
            msgDiv.style.background = "#fee";
            return;
        }
        if (password !== confirm) {
            msgDiv.innerHTML = "Пароли не совпадают";
            msgDiv.style.background = "#fee";
            return;
        }
        if (users.find(u => u.login === login)) {
            msgDiv.innerHTML = "Пользователь уже существует";
            msgDiv.style.background = "#fee";
            return;
        }
        
        users.push({ id: users.length + 1, login, password, token: "" });
        msgDiv.innerHTML = "✅ Регистрация успешна!";
        msgDiv.style.background = "#e6fffa";
        msgDiv.style.color = "#276749";
        setTimeout(() => showLoginForm(), 1500);
    };
    
    document.getElementById("backBtn").onclick = showLoginForm;
}

// ========== СТРАНИЦА КАТАЛОГА ==========
window.showCatalogPage = function(page = 1) {
    if (!currentUser) {
        showLoginForm();
        return;
    }
    
    currentPage = page;
    
    let filtered = electronicsShop.products;
    if (selectedCategory !== "Все") {
        filtered = filtered.filter(p => p.category === selectedCategory);
    }
    
    const sorted = getSortedProducts(filtered);
    const totalPages = Math.ceil(sorted.length / ITEMS_PER_PAGE);
    const paginated = getPaginatedProducts(sorted);
    
    let productsHtml = '';
    for (const p of paginated) {
        const discount = p.oldPrice ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;
        const stars = '★'.repeat(Math.floor(p.rating)) + '☆'.repeat(5 - Math.floor(p.rating));
        
        productsHtml += `
            <div class="product-card" onclick="goToProductPage(${p.id})">
                <button class="favorite-btn" onclick="event.stopPropagation(); toggleFavorite(${p.id})">${isFavorite(p.id) ? '❤️' : '🤍'}</button>
                <div class="product-image"><img src="${p.image}" onerror="this.src='https://placehold.co/200x200/1a1a2e/white?text=Product'"></div>
                <div class="product-title">${p.name}</div>
                <div class="product-brand">${p.brand}</div>
                <div class="rating">${stars} ${p.rating}</div>
                <div class="price-block"><span class="current-price">${p.price.toLocaleString()} ₽</span>${p.oldPrice ? `<span class="old-price">${p.oldPrice.toLocaleString()} ₽</span>` : ''}${discount > 0 ? `<span class="discount">-${discount}%</span>` : ''}</div>
                <div class="stock-status">${p.inStock ? '<span class="in-stock">✅ В наличии</span>' : '<span class="out-stock">❌ Нет в наличии</span>'}</div>
                <button class="buy-btn" onclick="event.stopPropagation(); buyProduct(${p.id})" ${!p.inStock ? 'disabled' : ''}>${p.inStock ? '🛒 Купить' : 'Нет в наличии'}</button>
            </div>
        `;
    }
    
    let catsHtml = '';
    for (const cat of categories) {
        catsHtml += `<button class="category-btn ${selectedCategory === cat ? 'active' : ''}" onclick="setCategory('${cat}')">${cat}</button>`;
    }
    
    app.innerHTML = `
        <div class="top-bar"><span class="shop-title">📱 ${electronicsShop.name}</span><button class="logout-btn" onclick="logout()">🚪 Выйти</button></div>
        <div class="categories">${catsHtml}</div>
        <div class="products-container">
            <div class="products-grid">${productsHtml || '<divclass="empty-state">📭 Товаров не найдено</div>'}</div>
            ${totalPages > 1 ? `<div class="pagination"><button class="page-btn" onclick="changePage(${currentPage-1})" ${currentPage===1 ? 'disabled' : ''}>◀</button><span class="page-info">${currentPage}/${totalPages}</span><button class="page-btn" onclick="changePage(${currentPage+1})" ${currentPage===totalPages ? 'disabled' : ''}>▶</button></div>` : ''}
        </div>
        <div class="bottom-nav">
            <button class="nav-item ${currentPage ? 'active' : ''}" onclick="window.showCatalogPage(1)"><span>🏠</span><span>Главная</span></button>
            <button class="nav-item" onclick="window.showFavoritesPage()"><span>❤️</span><span>Избранное</span><span class="nav-badge">${favorites.length}</span></button>
        </div>
    `;
};

// ========== СМЕНА СТРАНИЦЫ ==========
window.changePage = function(newPage) {
    if (!currentUser) return;
    let filtered = electronicsShop.products;
    if (selectedCategory !== "Все") filtered = filtered.filter(p => p.category === selectedCategory);
    const total = Math.ceil(filtered.length / ITEMS_PER_PAGE);
    if (newPage >= 1 && newPage <= total) window.showCatalogPage(newPage);
};

// ========== УСТАНОВКА КАТЕГОРИИ ==========
window.setCategory = function(cat) {
    if (!currentUser) return;
    selectedCategory = cat;
    window.showCatalogPage(1);
};

// ========== ВЫХОД ==========
window.logout = function() {
    currentUser = null;
    showLoginForm();
};

// ========== ПОКУПКА ==========
window.buyProduct = function(id) {
    const p = electronicsShop.products.find(p => p.id === id);
    alert(p && p.inStock ? `✅ Вы купили ${p.name} за ${p.price.toLocaleString()} ₽` : `❌ ${p?.name} нет в наличии`);
};

// ========== СТРАНИЦА ТОВАРА ==========
window.goToProductPage = function(id) {
    if (!currentUser) return;
    const p = electronicsShop.products.find(p => p.id === id);
    if (!p) return;
    
    const discount = p.oldPrice ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;
    const stars = '★'.repeat(Math.floor(p.rating)) + '☆'.repeat(5 - Math.floor(p.rating));
    
    app.innerHTML = `
        <div class="top-bar"><span class="shop-title">📱 ${electronicsShop.name}</span><button class="logout-btn" onclick="logout()">🚪 Выйти</button></div>
        <div class="product-page">
            <button class="back-btn" onclick="window.showCatalogPage(${currentPage})">← Назад</button>
            <div class="product-page-content">
                <div class="product-page-image"><img src="${p.image}"></div>
                <div class="product-page-info">
                    <button class="product-favorite-btn" onclick="toggleFavorite(${p.id}); goToProductPage(${p.id})">${isFavorite(p.id) ? '❤️ В избранном' : '🤍 В избранное'}</button>
                    <h1>${p.name}</h1>
                    <div class="product-brand">${p.brand}</div>
                    <div class="rating">${stars} ${p.rating}</div>
                    <div class="price-block"><span class="current-price">${p.price.toLocaleString()} ₽</span>${p.oldPrice ? `<span class="old-price">${p.oldPrice.toLocaleString()} ₽</span>` : ''}${discount > 0 ? `<span class="discount">-${discount}%</span>` : ''}</div>
                    <div class="stock-status">${p.inStock ? '<span class="in-stock">✅ В наличии</span>' : '<span class="out-stock">❌ Нет в наличии</span>'}</div>
                    <div class="product-description"><h3>Описание</h3><p>${p.description}</p></div>
                    <button class="buy-btn-large" onclick="buyProduct(${p.id})" ${!p.inStock ? 'disabled' : ''}>${p.inStock ? '🛒 Купить сейчас' : 'Нет в наличии'}</button>
                </div>
            </div>
        </div>
        <div class="bottom-nav">
            <button class="nav-item" onclick="window.showCatalogPage(1)"><span>🏠</span><span>Главная</span></button>
            <button class="nav-item" onclick="window.showFavoritesPage()"><span>❤️</span><span>Избранное</span><span cla


ss="nav-badge">${favorites.length}</span></button>
        </div>
    `;
};

// ========== СТРАНИЦА ИЗБРАННОГО ==========
window.showFavoritesPage = function() {
    if (!currentUser) { showLoginForm(); return; }
    
    const favProducts = electronicsShop.products.filter(p => favorites.includes(p.id));
    const sorted = getSortedProducts(favProducts);
    
    let html = '';
    for (const p of sorted) {
        const discount = p.oldPrice ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;
        const stars = '★'.repeat(Math.floor(p.rating)) + '☆'.repeat(5 - Math.floor(p.rating));
        html += `
            <div class="product-card" onclick="goToProductPage(${p.id})">
                <button class="favorite-btn active" onclick="event.stopPropagation(); toggleFavorite(${p.id}); window.showFavoritesPage();">❤️</button>
                <div class="product-image"><img src="${p.image}"></div>
                <div class="product-title">${p.name}</div>
                <div class="product-brand">${p.brand}</div>
                <div class="rating">${stars} ${p.rating}</div>
                <div class="price-block"><span class="current-price">${p.price.toLocaleString()} ₽</span>${p.oldPrice ? `<span class="old-price">${p.oldPrice.toLocaleString()} ₽</span>` : ''}${discount > 0 ? `<span class="discount">-${discount}%</span>` : ''}</div>
                <div class="stock-status">${p.inStock ? '<span class="in-stock">✅ В наличии</span>' : '<span class="out-stock">❌ Нет в наличии</span>'}</div>
                <button class="buy-btn" onclick="event.stopPropagation(); buyProduct(${p.id})" ${!p.inStock ? 'disabled' : ''}>${p.inStock ? '🛒 Купить' : 'Нет в наличии'}</button>
            </div>
        `;
    }
    
    app.innerHTML = `
        <div class="top-bar"><span class="shop-title">📱 ${electronicsShop.name}</span><button class="logout-btn" onclick="logout()">🚪 Выйти</button></div>
        <div class="products-container">
            <div class="products-header"><h1>❤️ Избранное</h1><p>${favorites.length} товаров</p></div>
            <div class="products-grid">${html || '<div class="empty-state">💔 Нет избранных товаров</div>'}</div>
        </div>
        <div class="bottom-nav">
            <button class="nav-item" onclick="window.showCatalogPage(1)"><span>🏠</span><span>Главная</span></button>
            <button class="nav-item active" onclick="window.showFavoritesPage()"><span>❤️</span><span>Избранное</span><span class="nav-badge">${favorites.length}</span></button>
        </div>
    `;
};

// ========== ЗАПУСК ==========
showLoginForm();