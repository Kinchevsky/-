
// В этот контейнер будем добавлять все элементы интерфейса
const fromUser = document.querySelector('#form-user');

// ФУНКЦИЯ СОЗДАНИЯ ФОРМЫ ВХОДА
// Эта функция создаёт все элементы формы авторизации
function addFrmpAuthorization() {
    
    // ПОЛЕ ДЛЯ ВВОДА ЛОГИНА
    const login = document.createElement("input");  // Создаём элемент <input>
    login.type = "text";                           // Тип поля - текст
    login.placeholder = "Логин";                   // Подсказка внутри поля
    login.pattern = "[a-zA-Z0-9]{3,15}";          // Регулярное выражение: только буквы и цифры, от 3 до 15 символов
    login.id = "login";                            // Уникальный ID для доступа из кода
    fromUser.appendChild(login);                   // Добавляем поле в контейнер
    
    // ПЕРЕВОД СТРОКИ (отступ)
    const br1 = document.createElement("br");
    fromUser.appendChild(br1);
    
    // ПОЛЕ ДЛЯ ВВОДА ПАРОЛЯ
    const password = document.createElement("input");
    password.type = "password";                    // Тип "password" - символы скрываются звёздочками
    password.placeholder = "Пароль";               // Подсказка
    password.id = "password";
    fromUser.appendChild(password);
    
    // ПЕРЕВОД СТРОКИ
    const br2 = document.createElement("br");
    fromUser.appendChild(br2);
    
    // КНОПКА "ВОЙТИ"
    const button = document.createElement("input");
    button.type = "button";                        // Кнопка (не отправляет форму)
    button.value = "Войти";                        // Текст на кнопке
    button.id = "btn";                             // ID для обработчика
    fromUser.appendChild(button);
    
    // КНОПКА "РЕГИСТРАЦИЯ"
    const regButton = document.createElement("input");
    regButton.type = "button";
    regButton.value = "Регистрация";               // Текст на кнопке
    regButton.id = "regBtn";
    regButton.style.marginLeft = "10px";           // Отступ слева для красоты
    fromUser.appendChild(regButton);
    
    // ПЕРЕВОД СТРОКИ
    const br3 = document.createElement("br");
    fromUser.appendChild(br3);
    
    // МЕСТО ДЛЯ СООБЩЕНИЙ
    const message = document.createElement("div");
    message.id = "message";                        // ID для доступа
    fromUser.appendChild(message);
}

// ВЫЗОВ ФУНКЦИИ ДЛЯ ОТОБРАЖЕНИЯ ФОРМЫ
addFrmpAuthorization();

// НАВЕШИВАЕМ ОБРАБОТЧИК НА КНОПКУ "ВОЙТИ"
// Находим кнопку по id и добавляем событие "click"
const btn = document.querySelector("#btn");
btn.addEventListener("click", getData);    // При клике вызывается функция getData

// НАВЕШИВАНИЕ ОБРАБОТЧИКА НА КНОПКУ "РЕГИСТРАЦИЯ"
const regBtn = document.querySelector("#regBtn");
regBtn.addEventListener("click", showRegisterForm);  // При клике открываем форму регистрации

// ФУНКЦИЯ ОБРАБОТКИ ВХОДА
// Срабатывает при нажатии на кнопку "Войти"
function getData() {
    // Получаем значения из полей ввода по их ID
    const login = document.querySelector("#login").value;      // Что ввёл пользователь в поле логина
    const password = document.querySelector("#password").value; // Что ввёл в поле пароля
    
    // ВАЛИДАЦИЯ (проверка) ЛОГИНА
    // Если длина меньше 3 или больше 15 символов
    if (login.length < 3 || login.length > 15) {
        showMessage("Логин должен быть 3-15 символов");  // Показываем ошибку
        return;  // Прерываем выполнение функции
    }
    
    // ВАЛИДАЦИЯ ПАРОЛЯ
    if (password.length < 3) {
        showMessage("Пароль должен быть минимум 3 символа");
        return;
    }
    
    // Если проверка пройдена - ищем пользователя в базе
    checkUser(login, password);
}

// ФУНКЦИЯ ПОИСКА ПОЛЬЗОВАТЕЛЯ ВБАЗЕ
// Принимает логин и пароль, проверяет есть ли такой в массиве users
function checkUser(login, password) {
    let user = null;  // Переменная для найденного пользователя (пока пустая)
    
    // Перебираем всех пользователей из массива users (из electronics.js)
    for (let i = 0; i < users.length; i++) {
        // Если логин И пароль совпадают
        if (users[i].login === login && users[i].password === password) {
            user = users[i];  // Сохраняем найденного пользователя
            break;            // Прерываем цикл (дальше искать не нужно)
        }
    }
    
    // Если пользователь НЕ найден (user остался равен null)
    if (user === undefined) {
        showMessage("Неверный логин или пароль");  // Показываем ошибку
    } else {
        // Если пользователь найден
        showMessage("Вход выполнен!", false);      // Показываем сообщение об успехе (зелёное)
        fromUser.innerHTML = "";                   // Очищаем весь контейнер
        showElectronicsShop();                     // Показываем магазин электроники
    }
}

// ФУНКЦИЯ ПОКАЗА ФОРМЫ РЕГИСТРАЦИИ
// Срабатывает при нажатии на кнопку "Регистрация"
function showRegisterForm() {
    // Очищаем контейнер (убираем форму входа)
    fromUser.innerHTML = "";
    
    // ЗАГОЛОВОК
    const title = document.createElement("h3");
    title.textContent = "Регистрация нового аккаунта";
    fromUser.appendChild(title);
    
    // ПОЛЕ ДЛЯ ЛОГИНА
    const loginLabel = document.createElement("label");
    loginLabel.textContent = "Логин (3-15 символов):";
    fromUser.appendChild(loginLabel);
    
    const loginInput = document.createElement("input");
    loginInput.type = "text";
    loginInput.id = "newLogin";
    fromUser.appendChild(loginInput);
    
    const br1 = document.createElement("br");
    fromUser.appendChild(br1);
    
    // ПОЛЕ ДЛЯ ПАРОЛЯ
    const passLabel = document.createElement("label");
    passLabel.textContent = "Пароль (мин. 3 символа):";
    fromUser.appendChild(passLabel);
    
    const passInput = document.createElement("input");
    passInput.type = "password";
    passInput.id = "newPassword";
    fromUser.appendChild(passInput);
    
    const br2 = document.createElement("br");
    fromUser.appendChild(br2);
    
    // ПОЛЕ ДЛЯ ПОДТВЕРЖДЕНИЯ ПАРОЛЯ
    const confirmLabel = document.createElement("label");
    confirmLabel.textContent = "Подтвердите пароль:";
    fromUser.appendChild(confirmLabel);
    
    const confirmInput = document.createElement("input");
    confirmInput.type = "password";
    confirmInput.id = "confirmPassword";
    fromUser.appendChild(confirmInput);
    
    const br3 = document.createElement("br");
    fromUser.appendChild(br3);
    fromUser.appendChild(document.createElement("br"));
    
    // КНОПКА "ЗАРЕГИСТРИРОВАТЬСЯ"
    const registerBtn = document.createElement("input");
    registerBtn.type = "button";
    registerBtn.value = "Зарегистрироваться";
    registerBtn.id = "doRegBtn";
    fromUser.appendChild(registerBtn);
    
    // КНОПКА "НАЗАД" (возврат к форме входа)
    const backBtn = document.createElement("input");
    backBtn.type = "button";
    backBtn.value = "Назад";
    backBtn.id = "backBtn";
    backBtn.style.marginLeft = "10px";
    fromUser.appendChild(backBtn);
    
    // МЕСТО ДЛЯ СООБЩЕНИЙ ОБ ОШИБКАХ
    const messageDiv = document.createElement("div");
    messageDiv.id = "regMessage";
    fromUser.appendChild(messageDiv);
    
    // Навешиваем обработчики на кнопки
    document.querySelector("#doRegBtn").addEventListener("click", doRegister);
    document.querySelector("#backBtn").addEventListener("click", function() {
        location.reload();  // Перезагружаем страницу (возврат к форме входа)
    });
}

// ФУНКЦИЯ ВЫПОЛНЕНИЯ РЕГИСТРАЦИИ
// Проверяет данные и добавляет нового пользователя в массив users
function doRegister() {
    // Получаем значения из полей формы регистрации
    const login = document.querySelector("#newLogin").value;
    const password = document.querySelector("#newPassword").value;
    const confirm = document.querySelector("#confirmPassword").value;
    
    // ПРОВЕРКА ЛОГИНА
    if (login.length < 3 || login.length > 15) {
        showRegMessage("Логин должен быть 3-15 символов (буквы и цифры)");
        return;
    }
    
    // ПРОВЕРКА ПАРОЛЯ
    if (password.length < 3) {
        showRegMessage("Пароль должен быть минимум 3 символа");
        return;
    }
    
    // ПРОВЕРКА СОВПАДЕНИЯ ПАРОЛЕЙ
    if (password !== confirm) {
        showRegMessage("Пароли не совпадают");
        return;
    }
    
    // ПРОВЕРКА: НЕТ ЛИ УЖЕ ТАКОГО ЛОГИНА
    for (let i = 0; i < users.length; i++) {
        if (users[i].login === login) {
            showRegMessage("Пользователь с таким логином уже существует");
            return;
        }
    }
    
    // ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ - СОЗДАЁМ НОВОГО ПОЛЬЗОВАТЕЛЯ
    const newId = users.length + 1;  // Новый ID = текущее количество + 1
    
    const newUser = {
        id: newId,
        login: login,
        password: password,
        token: ""
    };
    
    users.push(newUser);  // Добавляем в массив пользователей
    
    // Показываем сообщение об успехе (зелёное)
    showRegMessage("Регистрация успешна! Теперь войдите в аккаунт.", false);
    
    // Через 2 секунды (2000 миллисекунд) перезагружаем страницу
    // Это вернёт пользователя к форме входа
    setTimeout(function() {
        location.reload();
    }, 2000);
}

// ФУНКЦИЯ ДЛЯ ВЫВОДА СООБЩЕНИЙ В ФОРМЕ ВХОДА
// text - текст сообщения
// isError - true = красный (ошибка), false = зелёный (успех)
function showMessage(text, isError = true) {
    const msgDiv = document.querySelector("#message");
    if (msgDiv) {
        msgDiv.innerHTML = text;
        msgDiv.style.color = isError ? "red" : "green";
    }
}

// ФУНКЦИЯ ДЛЯ ВЫВОДА СООБЩЕНИЙ В ФОРМЕ РЕГИСТРАЦИИ
function showRegMessage(text, isError = true) {
    const msgDiv = document.querySelector("#regMessage");
    if (msgDiv) {
        msgDiv.innerHTML = text;
        msgDiv.style.color = isError ? "red" : "green";
    }
}

// ФУНКЦИЯ ОТОБРАЖЕНИЯ МАГАЗИНА ЭЛЕКТРОНИКИ
// Вызывается после успешного входа в аккаунт
function showElectronicsShop() {
    // Заголовок с названием магазина
    const title = document.createElement("h2");
    title.textContent = electronicsShop.name;
    fromUser.appendChild(title);
    
    // Перебираем все товары из electronics.js и создаём для каждого карточку
    for (let i = 0; i < electronicsShop.products.length; i++) {
        const product = electronicsShop.products[i];  // Текущий товар
        
        // Создаём контейнер для одного товара
        const productDiv = document.createElement("div");
        productDiv.style.border = "1px solid #ccc";   // Рамка
        productDiv.style.margin = "10px";             // Отступ снаружи
        productDiv.style.padding = "10px";            // Отступ внутри
        
        // Заполняем контейнер информацией о товаре
        productDiv.innerHTML = `
            <div style="display: flex; align-items: center; gap: 15px;">
                <img src="${product.image}" style="width: 80px; height: 80px; border-radius: 12px;">
                <div style="flex: 1;">
                    <h3>${product.name}</h3>
                    <p><strong>Бренд:</strong> ${product.brand}</p>
                    <p><strong>Цена:</strong> ${product.price} ₽</p>
                    <p><strong>Наличие:</strong> <span style="color: ${product.inStock ? '#38a169' : '#e53e3e'}">${product.inStock ? "В наличии" : "Нет в наличии"}</span></p>
                    <button onclick="buyProduct(${product.id})">Купить</button>
                </div>
            </div>
        `;
        
        // Добавляем карточку товара на страницу
        fromUser.appendChild(productDiv);
    }
    
    // КНОПКА "ВЫЙТИ" (завершение сессии)
    const logoutBtn = document.createElement("button");
    logoutBtn.textContent = "Выйти";
    logoutBtn.onclick = function() {
        location.reload();  // Перезагрузка страницы = выход из аккаунта
    };
    fromUser.appendChild(logoutBtn);
}

// ФУНКЦИЯ ПОКУПКИ ТОВАРА
// Срабатывает при нажатии на кнопку"Купить" у любого товара
// productId - ID товара, который хочет купить пользователь
window.buyProduct = function(productId) {
    // Перебираем все товары в поисках нужного ID
    for (let i = 0; i < electronicsShop.products.length; i++) {
        if (electronicsShop.products[i].id === productId) {
            const product = electronicsShop.products[i];
            
            // Проверяем, есть ли товар в наличии
            if (product.inStock) {
                alert("Вы купили " + product.name);  // Сообщение об успешной покупке
            } else {
                alert("Товара нет в наличии");       // Сообщение, если товара нет
            }
            break;  // Прерываем цикл, так как товар найден
        }
    }
};