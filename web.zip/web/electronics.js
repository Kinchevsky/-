
const electronicsShop = {
    name: "ТехноМир",
    
    products: [
        // Смартфоны (1-5)
        { id: 1, name: "Смартфон Galaxy S23", brand: "Samsung", price: 74990, inStock: true, category: "Смартфоны", image: "https://video-shoper.ru/upload/dev2fun.imagecompress/webp/iblock/47f/tjl0nzvx0t33baww2kyzqj0d9cwlw81j.webp", oldPrice: 89990, rating: 4.8, description: "Мощный смартфон с отличной камерой и большим экраном" },
        { id: 2, name: "Смартфон iPhone 15", brand: "Apple", price: 89990, inStock: true, category: "Смартфоны", image: "https://avatars.mds.yandex.net/i?id=e0017dccb91a9eff9ab6dbe146ea42bc8ab8f4d8-5233563-images-thumbs&n=13", oldPrice: 99990, rating: 4.9, description: "Новейший iPhone с динамическим островом" },
        { id: 3, name: "Смартфон Xiaomi 13", brand: "Xiaomi", price: 49990, inStock: true, category: "Смартфоны", image: "https://world-devices.ru/image/catalog/stati/123/3.jpg", oldPrice: 59990, rating: 4.7, description: "Флагманский смартфон с отличной камерой" },
        { id: 4, name: "Смартфон Pixel 8", brand: "Google", price: 64990, inStock: false, category: "Смартфоны", image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqewl-H2ioFPnognMFwo8bORg9ycgUM0aAnA&s", oldPrice: 74990, rating: 4.6, description: "Чистый Android и лучшая камера" },
        { id: 5, name: "Смартфон OnePlus 11", brand: "OnePlus", price: 54990, inStock: true, category: "Смартфоны", image: "https://ownlab.ru/wp-content/uploads/2013/07/439-500x375.jpg", oldPrice: 64990, rating: 4.7, description: "Быстрая зарядка и мощный процессор" },
        
        // Ноутбуки (6-10)
        { id: 6, name: "Ноутбук MacBook Air M2", brand: "Apple", price: 99990, inStock: true, category: "Ноутбуки", image: "https://ir-5.ozone.ru/s3/multimedia-1-4/wc1000/7269938632.jpg", oldPrice: 119990, rating: 4.9, description: "Лёгкий и мощный ноутбук с чипом M2" },
        { id: 7, name: "Ноутбук ROG Strix", brand: "ASUS", price: 129990, inStock: false, category: "Ноутбуки", image: "https://ir-5.ozone.ru/s3/multimedia-1-w/wc1000/9252478508.jpg", oldPrice: 149990, rating: 4.8, description: "Игровой ноутбук с мощной видеокартой" },
        { id: 8, name: "Ноутбук Legion 5", brand: "Lenovo", price: 89990, inStock: true, category: "Ноутбуки", image: "https://ir-5.ozone.ru/s3/multimedia-1-5/wc1000/9565090529.jpg", oldPrice: 104990, rating: 4.7, description: "Идеальный баланс цены и производительности" },
        { id: 9, name: "Ноутбук Swift 3", brand: "Acer", price: 69990, inStock: true, category: "Ноутбуки", image: "https://ir-5.ozone.ru/s3/multimedia-1-d/wc1000/9454121509.jpg", oldPrice: 79990, rating: 4.5, description: "Тонкий и лёгкий ультрабук" },
        { id: 10, name: "Ноутбук XPS 15", brand: "Dell", price: 149990, inStock: true, category: "Ноутбуки", image: "https://media.istockphoto.com/id/1760622302/ru/%D1%84%D0%BE%D1%82%D0%BE/%D0%BC%D1%83%D0%B6%D1%87%D0%B8%D0%BD%D0%B0-%D0%BD%D0%B0%D0%B6%D0%B8%D0%BC%D0%B0%D0%B5%D1%82-%D0%BA%D1%80%D0%B0%D1%81%D0%BD%D1%83%D1%8E-%D0%BA%D0%BD%D0%BE%D0%BF%D0%BA%D1%83-%D1%8F%D0%B4%D0%B5%D1%80%D0%BD%D0%BE%D0%B3%D0%BE-%D0%BE%D1%80%D1%83%D0%B6%D0%B8%D1%8F-%D0%BD%D0%B0-%D1%81%D0%B2%D0%B5%D1%82%D0%BB%D0%BE-%D1%81%D0%B5%D1%80%D0%BE%D0%BC-%D1%84%D0%BE%D0%BD%D0%B5-%D0%BA%D1%80%D1%83%D0%BF%D0%BD%D1%8B%D0%BC-%D0%BF%D0%BB%D0%B0%D0%BD%D0%BE%D0%BC-%D0%BA%D0%BE%D0%BD%D1%86%D0%B5%D0%BF%D1%86%D0%B8%D1%8F.jpg?s=2048x2048&w=is&k=20&c=q7lnafli8KSkq2JFK_9UmWiTeCKHbVXcQc1uQKKvUOg=", oldPrice: 169990, rating: 4.9, description: "Премиальный ноутбук для профессионалов" },
        
        // Аудио (11-14)
        { id: 11, name: "Наушники WH-1000XM5", brand: "Sony", price: 29990, inStock: false, category: "Аудио", image: "https://ir-5.ozone.ru/s3/multimedia-l/wc1000/6600721233.jpg", oldPrice: 34990, rating: 4.7, description: "Беспроводные наушники с шумоподавлением" },
        { id: 12, name: "Наушники AirPods Pro", brand: "Apple", price: 24990, inStock: true, category: "Аудио", image: "https://cs13.pikabu.ru/post_img/2019/11/13/9/1573653730162223774.jpg", oldPrice: 29990, rating: 4.8, description: "Беспроводные наушники с шумоподавлением" },
        { id: 13, name: "Колонка JBL Charge 5", brand: "JBL", price: 12990, inStock: true, category: "Аудио", image: "https://cs11.pikabu.ru/post_img/2020/09/16/6/1600246880160019644.jpg", oldPrice: 15990, rating: 4.6, description: "Мощная портативная колонка" },
        {id: 14, name: "Наушники QC 45", brand: "Bose", price: 27990, inStock: true, category: "Аудио", image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJcB-GNhBRbb-lEjiejGgmqxlKntWX2zCwuEhhv4Yspg&s", oldPrice: 32990, rating: 4.8, description: "Лучшее шумоподавление на рынке" },
        
        // Аксессуары (15-19)
        { id: 15, name: "Клавиатура MX Keys", brand: "Logitech", price: 10990, inStock: true, category: "Аксессуары", image: "https://ir-5.ozone.ru/s3/multimedia-1-3/wc1000/7349569275.jpg", oldPrice: 12990, rating: 4.6, description: "Удобная клавиатура с подсветкой" },
        { id: 16, name: "Мышь MX Master 3S", brand: "Logitech", price: 8990, inStock: false, category: "Аксессуары", image: "https://ir-5.ozone.ru/s3/multimedia-t/wc1000/6615096689.jpg", oldPrice: 10990, rating: 4.7, description: "Эргономичная мышь для профессионалов" },
        { id: 17, name: "Игровая приставка PS5", brand: "Sony", price: 49990, inStock: false, category: "Аксессуары", image: "https://ir-5.ozone.ru/s3/multimedia-1-p/wc1000/7340390269.jpg", oldPrice: 59990, rating: 4.9, description: "Новейшая игровая приставка" },
        { id: 18, name: "Геймпад Xbox", brand: "Microsoft", price: 4990, inStock: true, category: "Аксессуары", image: "https://ir-5.ozone.ru/s3/multimedia-1-q/wc1000/7640662346.jpg", oldPrice: 5990, rating: 4.7, description: "Удобный беспроводной геймпад" },
        { id: 19, name: "Внешний SSD 1TB", brand: "Samsung", price: 8990, inStock: true, category: "Аксессуары", image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRNwkvkQ8Nrb1aHqbR2SQF9cphS_r2nXcnxlw&s", oldPrice: 10990, rating: 4.8, description: "Быстрый и компактный накопитель" },
        
        // Мониторы (20-22)
        { id: 20, name: "Монитор 27\" 4K", brand: "LG", price: 34990, inStock: true, category: "Мониторы", image: "https://ir-5.ozone.ru/s3/multimedia-1-j/wc1000/8938443871.jpg", oldPrice: 42990, rating: 4.5, description: "4K монитор с отличной цветопередачей" },
        { id: 21, name: "Монитор Odyssey G7", brand: "Samsung", price: 49990, inStock: true, category: "Мониторы", image: "https://ir-5.ozone.ru/s3/multimedia-1-y/wc1000/7473156298.jpg", oldPrice: 59990, rating: 4.8, description: "Игровой монитор 240Hz" },
        { id: 22, name: "Монитор ProArt", brand: "ASUS", price: 64990, inStock: false, category: "Мониторы", image: "https://abrakadabra.fun/uploads/posts/2022-02/1645587819_25-abrakadabra-fun-p-prikol-razbitii-ekran-na-kompyuter-36.jpg", oldPrice: 74990, rating: 4.7, description: "Для дизайнеров и фотографов" },
        
        // Планшеты (23-25)
        { id: 23, name: "Планшет iPad Air", brand: "Apple", price: 59990, inStock: true, category: "Планшеты", image: "https://ir-5.ozone.ru/s3/multimedia-1-k/wc1000/7429681604.jpg", oldPrice: 69990, rating: 4.8, description: "Универсальный планшет для работы и творчества" },
        { id: 24, name: "Планшет Galaxy Tab S9", brand: "Samsung", price: 69990, inStock: true, category: "Планшеты", image: "https://ir-5.ozone.ru/s3/multimedia-1-2/wc1000/10344798614.jpg", oldPrice: 79990, rating: 4.7, description: "Мощный планшет с S Pen" },
        { id: 25, name: "Планшет MatePad 11", brand: "Huawei", price: 39990, inStock: true, category: "Планшеты", image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRoRv4ku6ZhIUKdc6qa6wP5QkE0OPLNX4PYqA&s", oldPrice: 45990, rating: 4.5, description: "Отличный бюджетный вариант" }
    ]
};

// Категории товаров
const categories = ["Все", "Смартфоны", "Ноутбуки", "Аудио", "Аксессуары", "Мониторы", "Планшеты"];

// База данных пользователей
let users = [
    { id: 1, login: "admin", password: "admin", token: "" }
];

// Избранное (хранится в localStorage)
let favorites = JSON.parse(localStorage.getItem("favorites")) || [];