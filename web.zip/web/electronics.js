// Данные магазина электроники
const electronicsShop = {
    name: "Магазин электроники",
    products: [
        { id: 1, name: "Смартфон", brand: "Samsung", price: 25000, inStock: true, image: "https://media.istockphoto.com/id/468046220/ru/фото/классический-красный-британский-телефон-будка-в-лондоне.jpg?s=612x612&w=0&k=20&c=oCYwpQfqEFdElu2v9rX_H36w_OqHvL1YQpOWso2dMKs=" },
        { id: 2, name: "Ноутбук", brand: "Apple", price: 80000, inStock: true, image: "https://habrastorage.org/r/w1560/getpro/habr/post_images/7c7/0be/e6a/7c70bee6a5ccfa87ca32fa98b41986e9.jpg" },
        { id: 3, name: "Наушники", brand: "Sony", price: 5000, inStock: false },
        { id: 4, name: "Планшет", brand: "Xiaomi", price: 15000, inStock: true },
        { id: 5, name: "Клавиатура", brand: "Logitech", price: 3000, inStock: true }
    ]
};

// База данных пользователей
let users = [
    {
        id: 1,
        login: "admin",
        password: "admin",
        token: ""
    }
];